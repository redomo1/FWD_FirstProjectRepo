#include <stdio.h>
#include"Application/app.h"

int main(void)
{
	appStart();

}