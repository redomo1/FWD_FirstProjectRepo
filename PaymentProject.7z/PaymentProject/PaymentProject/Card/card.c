
#include"card.h"
#include<stdio.h>
#include <string.h>
EN_cardError_t getCardHolderName(ST_cardData_t* cardData)
{

	int index = 0;
	char u8char;
	char u8cardHolderName[NAME_SIZE] = { 0 };

	EN_cardError_t cardState = WRONG_NAME;

	printf("Enter the cardholder  name in range[from 20 to 24 ]: \n");


	while ((u8char = getchar()) != '\n')
	{
		u8cardHolderName[index] = u8char;
		index++;
	}


	if ((index > 24) || (index < 20) || (u8cardHolderName == NULL))
	{
		cardState = WRONG_NAME;

	}
	else
	{
		cardState = OK;
		strcpy_s(cardData->cardHolderName, sizeof(cardData->cardHolderName), u8cardHolderName);
		
	}


	return cardState;
}

EN_cardError_t getCardExpiryDate(ST_cardData_t* cardData)
{
	EN_cardError_t ExpiryDateState = WRONG_EXP_DATE;
	int index = 0;
	char CardExpiryDate[10] = { 0 };
	uint8_t u8Month, u8Year;

	printf("Enter the Card Expiry Date in fromat[MM/YY] :\n");
	scanf_s("%s",CardExpiryDate,(unsigned)sizeof(CardExpiryDate));

	u8Month = (CardExpiryDate[0] - '0') * 10 + (CardExpiryDate[1] - '0');
	u8Year = (CardExpiryDate[3] - '0') * 10 + (CardExpiryDate[4] - '0');

	if ((CardExpiryDate == NULL) || (strlen(CardExpiryDate) < 5) || (strlen(CardExpiryDate) > 5))
	{
		ExpiryDateState = WRONG_EXP_DATE;

	}
	
    if (u8Month < 1 || u8Month > 12 || CardExpiryDate[2] != '/' || (u8Year > 99 || u8Year < 0))
    {
		ExpiryDateState = WRONG_EXP_DATE;
	}
	else
	{
		ExpiryDateState = OK;
			
	}
		strcpy_s(cardData->cardExpirationDate,sizeof(cardData->cardExpirationDate),CardExpiryDate);

	
	return ExpiryDateState;
}
EN_cardError_t getCardPAN(ST_cardData_t* cardData)
{
	EN_cardError_t enuCardPANState = WRONG_PAN;
	uint8_t PINNum[20] = { 0 };
	printf("Enter the PIN number [from 16 to 19 mun]:\n");
	scanf_s("%s",PINNum,(unsigned)sizeof(PINNum));
	if(PINNum == NULL || strlen(PINNum) > 19 || strlen(PINNum) < 16)
	{
		enuCardPANState = WRONG_PAN;
	}
	else
	{
		enuCardPANState = OK;

    }
	strcpy_s(cardData->primaryAccountNumber, sizeof(cardData->primaryAccountNumber), PINNum);
	return enuCardPANState;
}
