

#include"../Card/card.h"
#include"../Terminal/terminal.h"
#include "Server.h"
#include<string.h>
#include <stdio.h>
#include<stdbool.h>

ST_accountsDB_t  AccountsDB[255] = {

{1118.000000,RUNNING, "6228710870023450848"},
{1263.000000,BLOCKED, "2154156582386382610"},
{939.000000,RUNNING, "6665078994803810105"},
{1204.000000,BLOCKED, "1568038407049532096"},
{1108.000000,RUNNING, "8815861198228465537"},
{484.000000,BLOCKED, "1714287763473664781"},
{2827.000000,RUNNING, "6138026209917716679"},
{1251.000000,BLOCKED, "2731168220843666672"},
{349.000000,BLOCKED, "4143436656148421279"},
{1612.000000,RUNNING, "2684699010741461162"},
{2076.000000,RUNNING, "7246396600815173744"},
{660.000000,BLOCKED, "1068466573605963320"},
{1693.000000,RUNNING, "1082483214998592303"},
{77.000000,RUNNING, "2691320486308931298"},
{484.000000,BLOCKED, "5080790500006190161"},
{2219.000000,BLOCKED, "4383946547956873650"},
{1922.000000,RUNNING, "1774920811279480640"},
{2073.000000,RUNNING, "6523722072283601285"},
{3124.000000,BLOCKED, "9091327932415976897"},
{0} };
ST_transaction_t TransictionDB[255] = { 0 };
int index = -1;
static int count = 0;
EN_transState_t recieveTransactionData(ST_transaction_t* transData)
{
	EN_serverError_t IsValid;
	EN_transState_t  TransactionDataState;
	ST_accountsDB_t accountRefrence;

	if (isValidAccount(&transData->cardHolderData,&accountRefrence) == SERVER_OK)
	{
		if (isBlockedAccount(&accountRefrence) == SERVER_OK)
		{
			IsValid = isAmountAvailable(&transData->terminalData);
			if (IsValid == SERVER_OK)
			{
				IsValid = saveTransaction(transData);

				if (IsValid == SERVER_OK)
				{
					TransactionDataState = APPROVED;
					AccountsDB[index].balance -= transData->terminalData.transAmount;
				}
				else
				{
					TransactionDataState = INTERNAL_SERVER_ERROR;
				}
			}
			else
			{
				TransactionDataState = DECLINED_INSUFFECIENT_FUND;
			}
		}
		else
		{
			TransactionDataState = DECLINED_STOLEN_CARD;
		}

	}
	else
	{
		TransactionDataState = FRAUD_CARD;
	}
	
	transData->transState = TransactionDataState;
		return TransactionDataState;
}
EN_serverError_t isValidAccount(ST_cardData_t* cardData, ST_accountsDB_t* accountRefrence)
{
	EN_serverError_t IsValidState = ACCOUNT_NOT_FOUND;
	uint8_t* PANNum = cardData->primaryAccountNumber;

 	bool IsFound = false;
	bool Isequal = true;
	int i;
	for (i = 0; i < 255; i++) {

		if (AccountsDB[i].primaryAccountNumber[0] != '\0')
		{
			 Isequal = true;
			
		    if (strcmp(AccountsDB[i].primaryAccountNumber,PANNum) != 0U)
			{
				Isequal = false;
			}
			
			if (Isequal) 
			{
				IsFound = true;
				index = i;
				accountRefrence->state = AccountsDB[index].state;
				IsValidState = SERVER_OK;
			}
		}
		else 
		{
			break;
		}
	}
	return IsValidState;
}
EN_serverError_t isBlockedAccount(ST_accountsDB_t* accountRefrence)
{
	EN_serverError_t BlockedAccountState = BLOCKED_ACCOUNT;
	if (accountRefrence->state == RUNNING)
	{
		BlockedAccountState = SERVER_OK;
	}
	else
	{
		BlockedAccountState = BLOCKED_ACCOUNT;
	}
	return BlockedAccountState;
}
EN_serverError_t isAmountAvailable(ST_terminalData_t* termData)
{
	EN_serverError_t AmountAvailableState = LOW_BALANCE;


	if (AccountsDB[index].balance < termData->transAmount)
	{
		AmountAvailableState = LOW_BALANCE;
	}
	else
	{
		AmountAvailableState = SERVER_OK;
	}
	return AmountAvailableState;
}
EN_serverError_t saveTransaction(ST_transaction_t * transData)
{
	EN_serverError_t saveTransactionState = SAVING_FAILED;

	if (count < 255)
	{
		memcpy(TransictionDB[count].cardHolderData.cardHolderName ,transData->cardHolderData.cardHolderName,25);
		memcpy(TransictionDB[count].cardHolderData.primaryAccountNumber, transData->cardHolderData.primaryAccountNumber,20);
		memcpy(TransictionDB[count].cardHolderData.cardExpirationDate, transData->cardHolderData.cardExpirationDate,6);
		TransictionDB[count].terminalData.transAmount = transData->terminalData.transAmount;
		TransictionDB[count].terminalData.maxTransAmount = AccountsDB[index].balance - transData->terminalData.transAmount;
		memcpy(TransictionDB[count].terminalData.transactionDate,transData->terminalData.transactionDate,11);
		saveTransactionState = SERVER_OK;
	}
	else
	{
		saveTransactionState = SAVING_FAILED;
	}
	TransictionDB[count].transactionSequenceNumber = count + 1;
	if (getTransaction(count, transData) == SERVER_OK)
	{
		saveTransactionState = SERVER_OK;
	}
	else
	{
		saveTransactionState = SAVING_FAILED;
	}

	
	return saveTransactionState;
}
EN_serverError_t getTransaction(uint32_t transactionSequenceNumber, ST_transaction_t * transData)
{
	EN_serverError_t getTransactionState = TRANSACTION_NOT_FOUND;
	int i;
	if (transactionSequenceNumber <= 255)
	{
		for (i = 0; i <= count; i++)
		{
			if (transactionSequenceNumber == i)
			{
				memcpy( transData->cardHolderData.cardHolderName, TransictionDB[i].cardHolderData.cardHolderName, 25);
				memcpy( transData->cardHolderData.primaryAccountNumber, TransictionDB[i].cardHolderData.primaryAccountNumber, 20);
				memcpy( transData->cardHolderData.cardExpirationDate, TransictionDB[i].cardHolderData.cardExpirationDate, 6);
				transData->terminalData.transAmount = TransictionDB[i].terminalData.transAmount ;
				transData->terminalData.maxTransAmount = AccountsDB[i].balance ;
				memcpy( transData->terminalData.transactionDate, TransictionDB[i].terminalData.transactionDate, 11);
				getTransactionState = SERVER_OK;

				break;
			}
			else
			{
				//continue looping
			}

		}
	}

	return getTransactionState;

}
void PrintTransactionData(ST_transaction_t* transData)
{
	uint8_t u8Index;

	TransictionDB[count].transState = transData->transState;

	for (u8Index = 0; u8Index <= count; u8Index++)
	{
		
		printf("cardHolderName : %s\n", TransictionDB[u8Index].cardHolderData.cardHolderName);
		printf("primaryAccountNumber : %s\n", TransictionDB[u8Index].cardHolderData.primaryAccountNumber);
		printf("cardExpirationDate : %s\n", TransictionDB[u8Index].cardHolderData.cardExpirationDate);
		printf("transAmount : %f\n", TransictionDB[u8Index].terminalData.transAmount);
		printf("maxTransAmount : %f\n", TransictionDB[u8Index].terminalData.maxTransAmount);
		printf("transactionSequenceNumber : %d\n", TransictionDB[u8Index].transactionSequenceNumber);
		printf("balance:%f\n", AccountsDB[index].balance);
		if (TransictionDB[count].transState == APPROVED)
		{
			printf("Transiction state : APPROVED\n");
		}
		else if (TransictionDB[count].transState == DECLINED_INSUFFECIENT_FUND)
		{
			printf("Transiction state : DECLINED_INSUFFECIENT_FUND\n");
		}
		else if (TransictionDB[count].transState == DECLINED_STOLEN_CARD)
		{
			printf("Transiction state : DECLINED_STOLEN_CARD\n");
		}
		else if (TransictionDB[count].transState == INTERNAL_SERVER_ERROR)
		{
			printf("Transiction state : INTERNAL_SERVER_ERROR\n");
		}
		else
		{
			//Do Nothing
		}

	}
	count++;

}

