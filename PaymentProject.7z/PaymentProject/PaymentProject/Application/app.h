
#ifndef APP_H
#define APP_H
#include"../Card/card.h"
#include"../Terminal/terminal.h"
#include"../Server/server.h"
void appStart(void);





#endif
