#pragma warning(disable : 4996)
#include"terminal.h"
#include"../Card/card.h"
#include<stdio.h>
#include<string.h>


EN_terminalError_t getTransactionDate(ST_terminalData_t* termData)
{
	EN_terminalError_t  TransactionDateState = WRONG_DATE;
	int index = 0;
	char TransactionDate[15] = { 0 };
	uint8_t u8Month, u8Day;
	int u8Year;

	printf("Enter the Transaction Date in fromat[DD/MM/YYYY] :\n");
	(void)scanf("%s",TransactionDate);

	u8Day = (TransactionDate[0] - '0') * 10 + (TransactionDate[1] - '0');
	u8Month = (TransactionDate[3] - '0') * 10 + (TransactionDate[4] - '0');
	u8Year = (TransactionDate[6] - '0') * 1000 + (TransactionDate[7] - '0') * 100 + (TransactionDate[8] - '0') * 10 + (TransactionDate[9] - '0');

	if ((TransactionDate == NULL) || (strlen(TransactionDate) < 10U) || (strlen(TransactionDate) > 10U))
	{
		TransactionDateState = WRONG_DATE;

	}
		
	if (u8Day < 1U || u8Day> 31U || TransactionDate[2] != '/' || u8Month < 1U || u8Month> 12U || TransactionDate[5] != '/' || (u8Year > 2022U || u8Year < 0U))
	{
		TransactionDateState = WRONG_DATE;
	}
	else
	{
		TransactionDateState = OK_NO_TEMINAL_ERROR;
	}

	strcpy(&termData->transactionDate,TransactionDate);

	return TransactionDateState;
}
EN_terminalError_t isCardExpired(ST_cardData_t cardData, ST_terminalData_t termData)
{
	EN_terminalError_t CardExpiredState = EXPIRED_CARD;

	uint8_t u8termDataMonth, u8termDataYear;
	uint8_t u8cardDataMonth, u8cardDataYear;
	uint8_t u8YearDiff = 0;
	uint8_t u8MonthDiff = 0;
	u8termDataMonth = (termData.transactionDate[3] - '0') * 10 + (termData.transactionDate[4] - '0');
	u8termDataYear = (termData.transactionDate[8] - '0') * 10 + (termData.transactionDate[9] - '0');
	u8cardDataMonth = (cardData.cardExpirationDate[0] - '0') * 10 + (cardData.cardExpirationDate[1] - '0');
	u8cardDataYear = (cardData.cardExpirationDate[3] - '0') * 10 + (cardData.cardExpirationDate[4] - '0');
	if (u8cardDataMonth < u8termDataMonth)
	{ 
		u8cardDataMonth += 12U;
		u8cardDataYear -= 1U;
	}
	u8YearDiff = u8cardDataYear - u8termDataYear;
	u8MonthDiff = u8cardDataMonth - u8termDataMonth;
	if (u8MonthDiff < 0 || u8YearDiff < 0)
	{
		CardExpiredState = EXPIRED_CARD;
	}
	else
	{
		CardExpiredState = OK_NO_TEMINAL_ERROR;
	}
	return CardExpiredState;
}
EN_terminalError_t isValidCardPAN(ST_cardData_t* cardData)
{
	EN_terminalError_t ValidCardPANState = OK_NO_TEMINAL_ERROR;



	return ValidCardPANState;

}
EN_terminalError_t getTransactionAmount(ST_terminalData_t* termData)
{
	EN_terminalError_t TransactionAmountState = INVALID_AMOUNT;
	float TransAmount = 0;
	printf("Enter the transaction amount :\n");
	(void)scanf("%f",&TransAmount);
	if (TransAmount <= 0)
	{
		TransactionAmountState = INVALID_AMOUNT;
	}
	else
	{
		TransactionAmountState = OK_NO_TEMINAL_ERROR;
	
	}
	termData->transAmount = TransAmount;

	return TransactionAmountState;
}
EN_terminalError_t isBelowMaxAmount(ST_terminalData_t* termData)
{
	EN_terminalError_t BelowMaxAmountState = EXCEED_MAX_AMOUNT;
	if (termData->transAmount > termData->maxTransAmount)
	{
		BelowMaxAmountState = EXCEED_MAX_AMOUNT;
	}
	else
	{
		BelowMaxAmountState = OK_NO_TEMINAL_ERROR;
	}


	return BelowMaxAmountState;
}
EN_terminalError_t setMaxAmount(ST_terminalData_t* termData)
{
	EN_terminalError_t MaxAmountState = INVALID_MAX_AMOUNT;

	float MaxAmount = 0;

		printf("Enter the Max Amount:\n");
		scanf_s("%f", &MaxAmount);

	if (MaxAmount <= 0)
	{
		MaxAmountState = INVALID_MAX_AMOUNT;
	}
	else
	{
		MaxAmountState = OK_NO_TEMINAL_ERROR;
		
	}
	termData->maxTransAmount = MaxAmount;


	return MaxAmountState;
}